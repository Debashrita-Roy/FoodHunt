package com.example.foodhunt

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.TextView

class DisplayActivity : AppCompatActivity() {

    lateinit var hotelNameTextView: TextView
    lateinit var hotelnameTextView: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_display)

        hotelNameTextView = findViewById(R.id.hotelnameT)
        hotelnameTextView = findViewById(R.id.hotel2T)

        val i = intent.extras

        val hotel1 = i?.getString("hotel1")
        Log.d("DisplayActivity","$hotel1")
        val hotelName = hotel1?.split(',')?.get(1)
        Log.d("DisplayActivity","$hotelName")
        hotelNameTextView.setText(hotelName)

//        val hotel2 = i?.getString("hotel2")
//        Log.d("DisplayActivity","$hotel2")
//        val hotel2Name = hotel2?.split(',')?.get(1)
//        Log.d("DisplayActivity","$hotel2Name")
//        hotelnameTextView.setText(hotel2Name)

    }

}