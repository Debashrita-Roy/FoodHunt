package com.example.foodhunt

import android.content.Context
import android.service.autofill.UserData
import android.widget.ArrayAdapter

class UserAdapter(context: Context, UserData: MutableList<Users>){


}